EMMAH SOLO 🎸 PROFESSOR - Android App Project

This is an Android WebView project containing the guitar lesson dashboard.

IMPORTANT:
Replace app/src/main/assets/emmah.jpg with your own photo before building.
The file must be named exactly: emmah.jpg

To build:
1. Open this folder in Android Studio.
2. Allow Gradle to sync.
3. Build > Build APK(s).
4. Install the generated APK on your Android phone.

The dashboard HTML is in:
app/src/main/assets/index.html
